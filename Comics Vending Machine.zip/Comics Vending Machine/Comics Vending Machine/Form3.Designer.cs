﻿namespace Comics_Vending_Machine
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelPaymentMethod = new Label();
            labelComicName = new Label();
            labelAmount = new Label();
            labelDate = new Label();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // labelPaymentMethod
            // 
            labelPaymentMethod.AutoSize = true;
            labelPaymentMethod.Font = new Font("Century", 11.0769234F);
            labelPaymentMethod.Location = new Point(68, 106);
            labelPaymentMethod.Name = "labelPaymentMethod";
            labelPaymentMethod.Size = new Size(213, 23);
            labelPaymentMethod.TabIndex = 0;
            labelPaymentMethod.Text = "Metode Pembayaran :";
            // 
            // labelComicName
            // 
            labelComicName.AutoSize = true;
            labelComicName.Font = new Font("Century", 11.0769234F);
            labelComicName.Location = new Point(68, 29);
            labelComicName.Name = "labelComicName";
            labelComicName.Size = new Size(146, 23);
            labelComicName.TabIndex = 1;
            labelComicName.Text = "Nama Komik :";
            labelComicName.Click += labelComicName_Click;
            // 
            // labelAmount
            // 
            labelAmount.AutoSize = true;
            labelAmount.BackColor = SystemColors.ControlLight;
            labelAmount.Font = new Font("Century", 11.0769234F);
            labelAmount.Location = new Point(68, 64);
            labelAmount.Name = "labelAmount";
            labelAmount.Size = new Size(87, 23);
            labelAmount.TabIndex = 2;
            labelAmount.Text = "Harga  :";
            // 
            // labelDate
            // 
            labelDate.AutoSize = true;
            labelDate.Font = new Font("Century", 11.0769234F);
            labelDate.Location = new Point(68, 142);
            labelDate.Name = "labelDate";
            labelDate.Size = new Size(97, 23);
            labelDate.TabIndex = 3;
            labelDate.Text = "Tanggal :";
            // 
            // button1
            // 
            button1.Font = new Font("Century", 8.861538F);
            button1.Location = new Point(309, 284);
            button1.Name = "button1";
            button1.Size = new Size(203, 31);
            button1.TabIndex = 4;
            button1.Text = "Konfirmasi Pembayaran";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Century", 8.861538F);
            button2.Location = new Point(596, 284);
            button2.Name = "button2";
            button2.Size = new Size(102, 31);
            button2.TabIndex = 5;
            button2.Text = "Cancel";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form3
            // 
            AccessibleName = "Form3";
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(733, 348);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(labelDate);
            Controls.Add(labelAmount);
            Controls.Add(labelComicName);
            Controls.Add(labelPaymentMethod);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelPaymentMethod;
        private Label labelComicName;
        private Label labelAmount;
        private Label labelDate;
        private Button button1;
        private Button button2;
    }
}