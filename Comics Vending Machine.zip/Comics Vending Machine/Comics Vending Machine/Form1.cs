namespace Comics_Vending_Machine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string comicName = "Gokurakugai Vol. 1";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string comicName = "Gokurakugai Vol. 2";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string comicName = "Gokurakugai Vol. 3";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string comicName = "Gokurakugai Vol. 4";
            string price = "Rp 67.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string comicName = "Gokurakugai Vol. 5";
            string price = "Rp 70.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string comicName = "Blue Lock Vol. 1";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string comicName = "Blue Lock Vol. 3";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            string comicName = "Blue Lock Vol. 5";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            string comicName = "Blue Lock Vol. 6";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            string comicName = "Blue Lock Vol. 7";
            string price = "Rp 55.500";
            Form2 form2 = new Form2(comicName, price);
            form2.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
