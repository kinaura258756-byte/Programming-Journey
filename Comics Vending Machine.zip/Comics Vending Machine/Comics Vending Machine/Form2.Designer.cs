﻿namespace Comics_Vending_Machine
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBoxEWallet = new ComboBox();
            comboBoxMobileBanking = new ComboBox();
            btnPay = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 16.0615387F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(42, 36);
            label1.Name = "label1";
            label1.Size = new Size(352, 34);
            label1.TabIndex = 0;
            label1.Text = "Choose Payment Method";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.0769234F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(54, 116);
            label2.Name = "label2";
            label2.Size = new Size(85, 28);
            label2.TabIndex = 1;
            label2.Text = "E-Wallet";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.0769234F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(54, 181);
            label3.Name = "label3";
            label3.Size = new Size(149, 28);
            label3.TabIndex = 2;
            label3.Text = "Mobile Banking";
            // 
            // comboBoxEWallet
            // 
            comboBoxEWallet.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxEWallet.FormattingEnabled = true;
            comboBoxEWallet.Items.AddRange(new object[] { "OVO", "DANA ", "GoPay", "ShopeePay" });
            comboBoxEWallet.Location = new Point(274, 116);
            comboBoxEWallet.Name = "comboBoxEWallet";
            comboBoxEWallet.Size = new Size(212, 29);
            comboBoxEWallet.TabIndex = 3;
            comboBoxEWallet.SelectedIndexChanged += comboBoxEWallet_SelectedIndexChanged;
            // 
            // comboBoxMobileBanking
            // 
            comboBoxMobileBanking.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxMobileBanking.FormattingEnabled = true;
            comboBoxMobileBanking.Items.AddRange(new object[] { "BRImo", "BCA Mobile", "Livin' By Mandiri", "BNI Mobile Banking" });
            comboBoxMobileBanking.Location = new Point(274, 184);
            comboBoxMobileBanking.Name = "comboBoxMobileBanking";
            comboBoxMobileBanking.Size = new Size(212, 29);
            comboBoxMobileBanking.TabIndex = 4;
            comboBoxMobileBanking.SelectedIndexChanged += comboBoxMobileBanking_SelectedIndexChanged;
            // 
            // btnPay
            // 
            btnPay.BackColor = SystemColors.ActiveCaption;
            btnPay.Location = new Point(461, 392);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(102, 31);
            btnPay.TabIndex = 5;
            btnPay.Text = "Pay";
            btnPay.UseVisualStyleBackColor = false;
            btnPay.Click += btnPay_Click;
            // 
            // button2
            // 
            button2.Location = new Point(643, 392);
            button2.Name = "button2";
            button2.Size = new Size(102, 31);
            button2.TabIndex = 6;
            button2.Text = "Cancel";
            button2.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(btnPay);
            Controls.Add(comboBoxMobileBanking);
            Controls.Add(comboBoxEWallet);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBoxEWallet;
        private ComboBox comboBoxMobileBanking;
        private Button btnPay;
        private Button button2;
    }
}