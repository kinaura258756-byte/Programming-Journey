﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Comics_Vending_Machine
{
    public partial class Form3 : Form
    {
        private string paymentMethod;
        private string comicName;
        private string price;
        public Form3(string paymentMethod, string comicName, string price)
        {
            InitializeComponent();
            this.paymentMethod = paymentMethod;
            this.comicName = comicName;
            this.price = price;

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            labelPaymentMethod.Text = $"Metode Pembayaran       : {this.paymentMethod}";
            labelComicName.Text = $"Nama Komik                  : {comicName}";
            labelAmount.Text = $"Harga                             : {price}";
            labelDate.Text = $"Tanggal                          : {DateTime.Now.ToString("dd/MM/yyyy HH:mm")}";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pembayaran berhasil.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void labelComicName_Click(object sender, EventArgs e)
        {

        }
    }
}
