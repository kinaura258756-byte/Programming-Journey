﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Comics_Vending_Machine
{
    public partial class Form2 : Form
    {
        private string comicName;
        private string price;
        public Form2(string comicName, string price)
        {
            InitializeComponent();
            this.comicName = comicName;
            this.price = price;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnPay_Click(object sender, EventArgs e)
        {

            string paymentMethod = "";

            // Cek metode pembayaran yang dipilih
            if (comboBoxEWallet.SelectedItem != null)
                paymentMethod = comboBoxEWallet.SelectedItem.ToString();
            else if (comboBoxMobileBanking.SelectedItem != null)
                paymentMethod = comboBoxMobileBanking.SelectedItem.ToString();
            else
            {
                MessageBox.Show("Silakan pilih metode pembayaran terlebih dahulu.");
                return;
            }
            Form3 form3 = new Form3(paymentMethod, comicName, price);
            form3.Show();
            this.Hide();



        }

        private void comboBoxEWallet_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxMobileBanking.SelectedIndex = -1;
        }

        private void comboBoxMobileBanking_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxEWallet.SelectedIndex = -1;
        }
    }

}
