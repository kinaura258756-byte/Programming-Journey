﻿namespace Comics_Vending_Machine
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            label1 = new Label();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Location = new Point(64, 54);
            button1.Name = "button1";
            button1.Size = new Size(102, 146);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Location = new Point(250, 54);
            button2.Name = "button2";
            button2.Size = new Size(102, 146);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.BackgroundImage = (Image)resources.GetObject("button3.BackgroundImage");
            button3.BackgroundImageLayout = ImageLayout.Stretch;
            button3.Location = new Point(432, 54);
            button3.Name = "button3";
            button3.Size = new Size(102, 146);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.BackgroundImage = (Image)resources.GetObject("button4.BackgroundImage");
            button4.BackgroundImageLayout = ImageLayout.Stretch;
            button4.Location = new Point(615, 54);
            button4.Name = "button4";
            button4.Size = new Size(102, 146);
            button4.TabIndex = 3;
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.BackgroundImage = (Image)resources.GetObject("button5.BackgroundImage");
            button5.BackgroundImageLayout = ImageLayout.Stretch;
            button5.Location = new Point(802, 54);
            button5.Name = "button5";
            button5.Size = new Size(102, 146);
            button5.TabIndex = 4;
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.GradientActiveCaption;
            button6.Font = new Font("Century", 8.861538F);
            button6.Location = new Point(64, 248);
            button6.Name = "button6";
            button6.Size = new Size(102, 31);
            button6.TabIndex = 5;
            button6.Text = "Buy";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.GradientActiveCaption;
            button7.Font = new Font("Century", 8.861538F);
            button7.Location = new Point(250, 248);
            button7.Name = "button7";
            button7.Size = new Size(102, 31);
            button7.TabIndex = 6;
            button7.Text = "Buy";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.GradientActiveCaption;
            button8.Font = new Font("Century", 8.861538F);
            button8.Location = new Point(432, 248);
            button8.Name = "button8";
            button8.Size = new Size(102, 31);
            button8.TabIndex = 7;
            button8.Text = "Buy";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.GradientActiveCaption;
            button9.Font = new Font("Century", 8.861538F);
            button9.Location = new Point(615, 248);
            button9.Name = "button9";
            button9.Size = new Size(102, 31);
            button9.TabIndex = 8;
            button9.Text = "Buy";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.GradientActiveCaption;
            button10.Font = new Font("Century", 8.861538F);
            button10.Location = new Point(802, 249);
            button10.Name = "button10";
            button10.Size = new Size(102, 31);
            button10.TabIndex = 9;
            button10.Text = "Buy";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 8.861538F);
            label1.Location = new Point(76, 213);
            label1.Name = "label1";
            label1.Size = new Size(83, 20);
            label1.TabIndex = 10;
            label1.Text = "Rp 55.500";
            label1.Click += label1_Click;
            // 
            // button11
            // 
            button11.BackgroundImage = (Image)resources.GetObject("button11.BackgroundImage");
            button11.BackgroundImageLayout = ImageLayout.Stretch;
            button11.Location = new Point(802, 349);
            button11.Name = "button11";
            button11.Size = new Size(102, 146);
            button11.TabIndex = 15;
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.BackgroundImage = (Image)resources.GetObject("button12.BackgroundImage");
            button12.BackgroundImageLayout = ImageLayout.Stretch;
            button12.Location = new Point(615, 349);
            button12.Name = "button12";
            button12.Size = new Size(102, 146);
            button12.TabIndex = 14;
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.BackgroundImage = (Image)resources.GetObject("button13.BackgroundImage");
            button13.BackgroundImageLayout = ImageLayout.Stretch;
            button13.Location = new Point(432, 349);
            button13.Name = "button13";
            button13.Size = new Size(102, 146);
            button13.TabIndex = 13;
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.BackgroundImage = (Image)resources.GetObject("button14.BackgroundImage");
            button14.BackgroundImageLayout = ImageLayout.Stretch;
            button14.Location = new Point(250, 349);
            button14.Name = "button14";
            button14.Size = new Size(102, 146);
            button14.TabIndex = 12;
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.BackgroundImage = (Image)resources.GetObject("button15.BackgroundImage");
            button15.BackgroundImageLayout = ImageLayout.Stretch;
            button15.Location = new Point(64, 349);
            button15.Name = "button15";
            button15.Size = new Size(102, 146);
            button15.TabIndex = 11;
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.GradientActiveCaption;
            button16.Font = new Font("Century", 8.861538F);
            button16.Location = new Point(802, 548);
            button16.Name = "button16";
            button16.Size = new Size(102, 31);
            button16.TabIndex = 20;
            button16.Text = "Buy";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.BackColor = SystemColors.GradientActiveCaption;
            button17.Font = new Font("Century", 8.861538F);
            button17.Location = new Point(615, 547);
            button17.Name = "button17";
            button17.Size = new Size(102, 31);
            button17.TabIndex = 19;
            button17.Text = "Buy";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.BackColor = SystemColors.GradientActiveCaption;
            button18.Font = new Font("Century", 8.861538F);
            button18.Location = new Point(432, 547);
            button18.Name = "button18";
            button18.Size = new Size(102, 31);
            button18.TabIndex = 18;
            button18.Text = "Buy";
            button18.UseVisualStyleBackColor = false;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.BackColor = SystemColors.GradientActiveCaption;
            button19.Font = new Font("Century", 8.861538F);
            button19.Location = new Point(250, 547);
            button19.Name = "button19";
            button19.Size = new Size(102, 31);
            button19.TabIndex = 17;
            button19.Text = "Buy";
            button19.UseVisualStyleBackColor = false;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.BackColor = SystemColors.GradientActiveCaption;
            button20.Font = new Font("Century", 8.861538F);
            button20.Location = new Point(64, 547);
            button20.Name = "button20";
            button20.Size = new Size(102, 31);
            button20.TabIndex = 16;
            button20.Text = "Buy";
            button20.UseVisualStyleBackColor = false;
            button20.Click += button20_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century", 8.861538F);
            label2.Location = new Point(262, 213);
            label2.Name = "label2";
            label2.Size = new Size(83, 20);
            label2.TabIndex = 21;
            label2.Text = "Rp 55.500";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century", 8.861538F);
            label3.Location = new Point(442, 213);
            label3.Name = "label3";
            label3.Size = new Size(83, 20);
            label3.TabIndex = 22;
            label3.Text = "Rp 55.500";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century", 8.861538F);
            label4.Location = new Point(627, 213);
            label4.Name = "label4";
            label4.Size = new Size(83, 20);
            label4.TabIndex = 23;
            label4.Text = "Rp 67.500";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century", 8.861538F);
            label5.Location = new Point(811, 213);
            label5.Name = "label5";
            label5.Size = new Size(83, 20);
            label5.TabIndex = 24;
            label5.Text = "Rp 70.500";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Century", 8.861538F);
            label6.Location = new Point(811, 511);
            label6.Name = "label6";
            label6.Size = new Size(83, 20);
            label6.TabIndex = 29;
            label6.Text = "Rp 70.500";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century", 8.861538F);
            label7.Location = new Point(627, 511);
            label7.Name = "label7";
            label7.Size = new Size(83, 20);
            label7.TabIndex = 28;
            label7.Text = "Rp 60.000";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century", 8.861538F);
            label8.Location = new Point(442, 511);
            label8.Name = "label8";
            label8.Size = new Size(83, 20);
            label8.TabIndex = 27;
            label8.Text = "Rp 60.000";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century", 8.861538F);
            label9.Location = new Point(262, 511);
            label9.Name = "label9";
            label9.Size = new Size(83, 20);
            label9.TabIndex = 26;
            label9.Text = "Rp 51.000";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century", 8.861538F);
            label10.Location = new Point(76, 511);
            label10.Name = "label10";
            label10.Size = new Size(83, 20);
            label10.TabIndex = 25;
            label10.Text = "Rp 51.000";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1026, 623);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button16);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(label1);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Label label1;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
    }
}
